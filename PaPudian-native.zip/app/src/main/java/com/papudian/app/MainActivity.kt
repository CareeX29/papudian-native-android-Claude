package com.papudian.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Bg = Color(0xFFFAF9F6)
private val Ink = Color(0xFF33363A)
private val Muted = Color(0xFF8A8D91)
private val Line = Color(0xFFE8E6E0)
private val Accent = Color(0xFF6F8F86)
private val Chip = Color(0xFFEEF2F0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val buku = remember { loadBuku(ctx) }
    val pager = rememberPagerState { buku.size }
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<Pair<Int, Lagu>?>(null) }
    val queries = remember { mutableStateListOf("", "") }
    val listStates = buku.map { rememberLazyListState() }

    BackHandler(enabled = selected != null) { selected = null }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().imePadding()
    ) {
        val sel = selected
        if (sel == null) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                buku.forEachIndexed { i, b ->
                    val on = pager.currentPage == i
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (on) Accent else Chip)
                            .clickable { scope.launch { pager.animateScrollToPage(i) } }
                            .padding(horizontal = 6.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            b.nama, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                            color = if (on) Color.White else Ink, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                BookList(buku[page], queries[page], listStates[page],
                    onQuery = { queries[page] = it }, onOpen = { selected = page to it })
            }
        } else {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFFCFE6DA)).clickable { selected = null }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text("\u2190 Kembali", color = Color(0xFF2E5D4E), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
                Text(
                    buku[sel.first].nama, fontSize = 19.sp, fontWeight = FontWeight.SemiBold,
                    color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Detail(buku[sel.first].nama, sel.second)
        }
    }
}


@Composable
fun BookList(
    b: Buku, query: String, state: androidx.compose.foundation.lazy.LazyListState,
    onQuery: (String) -> Unit, onOpen: (Lagu) -> Unit,
) {
    val t = query.trim().lowercase()
    val hasil = remember(b, t) {
        b.lagu.filter { it.nomor.lowercase().startsWith(t) || it.judul.lowercase().contains(t) }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        BasicTextField(
            value = query, onValueChange = onQuery, singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 16.sp),
            cursorBrush = SolidColor(Accent),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            decorationBox = { inner ->
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White)
                        .border(1.dp, Line, RoundedCornerShape(10.dp)).padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    if (query.isEmpty()) Text("Cari judul atau nomor lagu", color = Muted, fontSize = 16.sp)
                    inner()
                }
            }
        )
        if (hasil.isEmpty()) {
            Text(
                "Lagu tidak ditemukan. Coba judul atau nomor lain.", color = Muted,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp)
            )
        } else {
            LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
                items(hasil, key = { it.nomor + it.judul }) { l ->
                    Column(Modifier.fillMaxWidth().clickable { onOpen(l) }) {
                        Row(Modifier.padding(horizontal = 4.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            Text(l.nomor, color = Muted, modifier = Modifier.widthIn(min = 34.dp), fontSize = 16.sp)
                            Text(l.judul, color = Ink, fontSize = 16.sp)
                        }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
                    }
                }
            }
        }
    }
}

@Composable
fun Detail(bukuNama: String, l: Lagu) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 60.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(12.dp))
        Text("$bukuNama \u00b7 No. ${l.nomor}", color = Muted, fontSize = 14.sp)
        Text(
            l.judul, fontSize = 28.sp, lineHeight = 35.sp, fontWeight = FontWeight.SemiBold,
            color = Ink, textAlign = TextAlign.Center
        )
        if (l.rujukan.isNotEmpty()) Text(l.rujukan, color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
        Row(Modifier.padding(top = 14.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (l.nadaDasar.isNotEmpty()) Pill(l.nadaDasar)
            if (l.tempo.isNotEmpty()) {
                val bir = Regex("\\d/\\d").containsMatchIn(l.tempo)
                Pill((if (bir) "Birama: " else "Tempo: ") + l.tempo)
            }
        }
        if (l.not.isNotEmpty()) Text(l.not, color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(20.dp))
        Column(Modifier.fillMaxWidth()) { Lirik(l.lirik) }
    }
}

@Composable
fun Pill(t: String) {
    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Chip).padding(horizontal = 12.dp, vertical = 4.dp)) {
        Text(t, fontSize = 14.sp, color = Ink)
    }
}

@Composable
fun Lirik(teks: String) {
    val bait = teks.trim().split(Regex("\\n\\s*\\n"))
    bait.forEach { b ->
        if (!b.contains('[')) {
            Column(Modifier.padding(bottom = 26.dp)) {
                b.split("\n").forEach { Text(it, fontSize = 16.sp, lineHeight = 29.sp, color = Ink) }
            }
        } else {
            Column(Modifier.padding(bottom = 26.dp).horizontalScroll(rememberScrollState())) {
                b.split("\n").forEach { baris -> NoteLine(baris) }
            }
        }
    }
}

private data class Tok(val s: String, val beam: Boolean, val spBeam: Boolean, val first: Boolean)

private class Segment(val toks: List<Tok>, val gapBeam: Boolean, val text: String)

private fun parseLine(baris: String): List<Segment> {
    val parts = mutableListOf<String>()
    var last = 0
    Regex("\\[[^\\]]*\\]").findAll(baris).forEach { m ->
        if (m.range.first > last) parts.add(baris.substring(last, m.range.first))
        parts.add(m.value); last = m.range.last + 1
    }
    if (last < baris.length) parts.add(baris.substring(last))
    val segs = mutableListOf<Segment>()
    var chord = ""
    var inBeam = false
    fun add(c: String, t: String) {
        val toks = mutableListOf<Tok>()
        val list = if (c.isNotEmpty()) c.split(Regex("\\s+")).filter { it.isNotEmpty() } else emptyList()
        list.forEachIndexed { i, tk ->
            val st = tk.length > 1 && tk[0] == '_'
            val en = tk.length > 1 && tk.endsWith('_')
            val spBeam = inBeam
            val nBeam = inBeam || st
            toks.add(Tok(tk.removePrefix("_").removeSuffix("_"), nBeam, spBeam, i == 0))
            if (en) inBeam = false else if (st) inBeam = true
        }
        segs.add(Segment(toks, inBeam, if (t.isEmpty()) " " else t))
    }
    parts.forEach { p ->
        if (p.startsWith("[") && p.endsWith("]")) {
            if (chord.isNotEmpty()) add(chord, "")
            chord = p.substring(1, p.length - 1)
        } else {
            add(chord, p); chord = ""
        }
    }
    if (chord.isNotEmpty()) add(chord, "")
    return segs
}

@Composable
fun NoteLine(baris: String) {
    if (!baris.contains('[')) {
        Text(baris, fontSize = 16.sp, color = Ink, softWrap = false)
        return
    }
    val segs = remember(baris) { parseLine(baris) }
    Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(vertical = 1.dp)) {
        segs.forEach { sg ->
            Column(Modifier.width(IntrinsicSize.Max)) {
                Row(Modifier.fillMaxWidth().heightIn(min = 22.dp)) {
                    sg.toks.forEach { tk ->
                        if (!tk.first) Spacer(Modifier.width(6.dp).height(22.dp).beam(tk.spBeam))
                        Text(
                            tk.s, color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                            softWrap = false, modifier = Modifier.padding(horizontal = 1.dp).beam(tk.beam)
                        )
                    }
                    Spacer(Modifier.weight(1f).widthIn(min = 8.dp).height(22.dp).beam(sg.gapBeam))
                }
                Text(sg.text, fontSize = 16.sp, color = Ink, softWrap = false)
            }
        }
    }
}

private fun Modifier.beam(on: Boolean): Modifier = if (!on) this else this.drawBehind {
    drawLine(Accent, Offset(0f, 1f), Offset(size.width, 1f), strokeWidth = 2.dp.toPx())
}
