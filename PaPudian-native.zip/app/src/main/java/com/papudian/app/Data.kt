package com.papudian.app

import android.content.Context
import org.json.JSONArray

data class Lagu(
    val nomor: String,
    val judul: String,
    val nadaDasar: String,
    val tempo: String,
    val rujukan: String,
    val not: String,
    val lirik: String,
)

data class Buku(val nama: String, val lagu: List<Lagu>)

private fun load(ctx: Context, file: String): List<Lagu> {
    val text = ctx.assets.open(file).bufferedReader(Charsets.UTF_8).use { it.readText() }
    val arr = JSONArray(text)
    return List(arr.length()) { i ->
        val o = arr.getJSONObject(i)
        Lagu(
            o.optString("nomor"), o.optString("judul"), o.optString("nada_dasar"),
            o.optString("tempo"), o.optString("rujukan"), o.optString("not"), o.optString("lirik"),
        )
    }
}

fun loadBuku(ctx: Context): List<Buku> = listOf(
    Buku("Pa'Pudian", load(ctx, "lagu_papudian.json")),
    Buku("Penanian Masallo\u2019", load(ctx, "lagu_penanian.json")),
)
