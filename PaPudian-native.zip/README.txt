Pa'Pudian - Android native (Kotlin + Jetpack Compose), tanpa HTML/WebView.
Cara build dari HP: upload isi folder ini ke repo GitHub baru (pakai Upload files di browser),
lalu buka tab Actions > Build APK > Run workflow. Unduh APK dari Artifacts: PaPudian-apk.
